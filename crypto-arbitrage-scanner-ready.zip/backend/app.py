from fastapi import FastAPI
app=FastAPI()

@app.get("/")
def root():
    return {
      "scanner":"crypto arbitrage",
      "exchanges":["mexc","kucoin","okx"],
      "markets":["spot","futures"],
      "pairs":"all */USDT",
      "features":["funding","spread","buy_exchange","sell_exchange"]
    }

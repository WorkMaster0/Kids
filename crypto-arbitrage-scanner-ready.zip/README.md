# Crypto Arbitrage Scanner

Upload to GitHub and deploy:
Frontend -> Vercel
Backend -> Railway
